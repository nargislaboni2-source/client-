package com.ssclient.bedrock
import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.widget.*
import android.graphics.Color

class MainActivity : Activity() {
 private fun btn(s:String)=Button(this).apply{text=s;setTextColor(Color.WHITE);setBackgroundColor(Color.rgb(22,139,255))}
 override fun onCreate(savedInstanceState:Bundle?){super.onCreate(savedInstanceState)
  val root=LinearLayout(this).apply{orientation=1;gravity=Gravity.CENTER;setPadding(28,30,28,30);setBackgroundColor(Color.rgb(7,20,38))}
  root.addView(TextView(this).apply{text="SS BEDROCK CLIENT";textSize=26f;gravity=Gravity.CENTER;setTextColor(Color.WHITE)})
  root.addView(TextView(this).apply{text="BLUE GLOW • NATIVE OVERLAY";gravity=Gravity.CENTER;setTextColor(Color.LTGRAY);setPadding(0,12,0,28)})
  root.addView(btn("ENABLE FLOATING SS BUTTON").apply{setOnClickListener{enableOverlay()}},LinearLayout.LayoutParams(-1,58))
  root.addView(btn("OPEN MINECRAFT").apply{setOnClickListener{
   if(!Settings.canDrawOverlays(this@MainActivity)){enableOverlay();return@setOnClickListener}
   startService(Intent(this@MainActivity,OverlayService::class.java))
   val game=packageManager.getLaunchIntentForPackage("com.mojang.minecraftpe")
   if(game!=null) startActivity(game) else Toast.makeText(this@MainActivity,"Minecraft পাওয়া যায়নি",Toast.LENGTH_LONG).show()
  }},LinearLayout.LayoutParams(-1,58).apply{topMargin=12})
  root.addView(TextView(this).apply{text="প্রথমে overlay permission চালু করো, তারপর আবার Enable চাপো।";setTextColor(Color.LTGRAY);gravity=Gravity.CENTER;setPadding(8,24,8,0)})
  setContentView(root)
 }
 private fun enableOverlay(){if(!Settings.canDrawOverlays(this)) startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,Uri.parse("package:$packageName"))) else startService(Intent(this,OverlayService::class.java))}
}
