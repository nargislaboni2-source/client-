package com.ssclient.bedrock
import android.app.Service
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.os.Build
import android.os.IBinder
import android.view.*
import android.widget.*

class OverlayService:Service(){
 private lateinit var wm:WindowManager
 private var bubble:TextView?=null
 private var panel:LinearLayout?=null
 private var cross:TextView?=null
 private var tapCount=0
 private fun type()=if(Build.VERSION.SDK_INT>=26) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY else WindowManager.LayoutParams.TYPE_PHONE
 private fun lp(w:Int,h:Int,g:Int=Gravity.TOP or Gravity.START)=WindowManager.LayoutParams(w,h,type(),WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,PixelFormat.TRANSLUCENT).apply{gravity=g;x=20;y=180}
 override fun onCreate(){super.onCreate();wm=getSystemService(WINDOW_SERVICE) as WindowManager;showBubble()}
 private fun showBubble(){
  if(bubble!=null)return
  val v=TextView(this).apply{text="SS";textSize=18f;typeface=Typeface.DEFAULT_BOLD;gravity=Gravity.CENTER;setTextColor(Color.WHITE);setBackgroundColor(Color.rgb(10,93,190))}
  val p=lp(58,58);bubble=v;wm.addView(v,p)
  v.setOnTouchListener(object:View.OnTouchListener{
   var sx=0f;var sy=0f;var ox=0;var oy=0;var moved=false
   override fun onTouch(view:View,e:MotionEvent):Boolean{val q=view.layoutParams as WindowManager.LayoutParams
    when(e.action){
     MotionEvent.ACTION_DOWN->{sx=e.rawX;sy=e.rawY;ox=q.x;oy=q.y;moved=false;return true}
     MotionEvent.ACTION_MOVE->{val dx=(e.rawX-sx).toInt();val dy=(e.rawY-sy).toInt();if(kotlin.math.abs(dx)+kotlin.math.abs(dy)>8)moved=true;q.x=ox+dx;q.y=oy+dy;wm.updateViewLayout(view,q);return true}
     MotionEvent.ACTION_UP->{if(!moved)togglePanel();return true}
    };return false
   }
  })
 }
 private fun togglePanel(){if(panel==null)showPanel() else hidePanel()}
 private fun showPanel(){
  val box=LinearLayout(this).apply{orientation=1;setPadding(16,14,16,14);setBackgroundColor(Color.rgb(7,20,38))}
  box.addView(TextView(this).apply{text="SS CLIENT • BLUE GLOW";textSize=16f;typeface=Typeface.DEFAULT_BOLD;setTextColor(Color.rgb(75,170,255))})
  val count=TextView(this).apply{text="CPS TEST: 0";textSize=20f;setTextColor(Color.WHITE);setPadding(0,10,0,10)}
  box.addView(count)
  box.addView(Button(this).apply{text="TAP TEST";setOnClickListener{tapCount++;count.text="TAPS: $tapCount"}})
  box.addView(Button(this).apply{text="TOGGLE CENTER CROSSHAIR";setOnClickListener{toggleCross()}})
  box.addView(TextView(this).apply{text="CPS counts taps on this panel only. Crosshair is a screen overlay preview.";textSize=11f;setTextColor(Color.LTGRAY);setPadding(0,8,0,8)})
  box.addView(Button(this).apply{text="CLOSE";setOnClickListener{hidePanel()}})
  val p=lp(280,WindowManager.LayoutParams.WRAP_CONTENT);p.x=85;p.y=220;panel=box;wm.addView(box,p)
 }
 private fun toggleCross(){
  if(cross!=null){try{wm.removeView(cross)}catch(_:Exception){};cross=null;return}
  val v=TextView(this).apply{text="+";textSize=32f;gravity=Gravity.CENTER;setTextColor(Color.WHITE)}
  val p=lp(44,44,Gravity.CENTER);p.flags=WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN
  cross=v;wm.addView(v,p)
 }
 private fun hidePanel(){panel?.let{try{wm.removeView(it)}catch(_:Exception){}};panel=null}
 override fun onDestroy(){hidePanel();cross?.let{try{wm.removeView(it)}catch(_:Exception){}};bubble?.let{try{wm.removeView(it)}catch(_:Exception){}};super.onDestroy()}
 override fun onBind(intent:Intent?):IBinder?=null
}
